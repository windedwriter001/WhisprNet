from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.core.files.storage import FileSystemStorage
from p_app import dbconnection
from datetime import datetime, timedelta, date
import random
import os
import base64
import hashlib
import mimetypes
import os
import random
from django.http import HttpResponseRedirect
from django.core.mail import send_mail

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7
from cryptography.hazmat.backends import default_backend
import easygui


# ================== COMMON ==================
IV = b'\x00' * 16


# ================== TEXT ENCRYPT / DECRYPT ==================
def get_text_key():
    password = os.environ.get("TEXT_ENCRYPTION_PASSWORD", "").encode()
    if not password:
        raise RuntimeError("Set TEXT_ENCRYPTION_PASSWORD before using text encryption.")
    return hashlib.sha256(password).digest()


def encrypt(text):
    padder = PKCS7(128).padder()
    padded = padder.update(text.encode()) + padder.finalize()

    cipher = Cipher(algorithms.AES(get_text_key()), modes.CBC(IV), backend=default_backend())
    encryptor = cipher.encryptor()

    encrypted = encryptor.update(padded) + encryptor.finalize()
    return base64.b64encode(encrypted).decode()


def decrypt(text):
    cipher = Cipher(algorithms.AES(get_text_key()), modes.CBC(IV), backend=default_backend())
    decryptor = cipher.decryptor()

    decrypted = decryptor.update(base64.b64decode(text)) + decryptor.finalize()

    unpadder = PKCS7(128).unpadder()
    return (unpadder.update(decrypted) + unpadder.finalize()).decode()


# ================== FILE ENCRYPT ==================
def encrypt_file(request, uploaded_file, output_path):

    uid = request.session['uid']

    qry1 = "select * from user_data where em='" + uid + "'"
    data1 = dbconnection.selectdata(qry1)

    qry2 = "select * from dis_data where em='" + data1[7] + "'"
    data2 = dbconnection.selectdata(qry2)

    ekey = data2[5]                     # distributor key
    FILE_KEY = hashlib.sha256(ekey.encode()).digest()

    data = uploaded_file.read()

    padder = PKCS7(128).padder()
    padded = padder.update(data) + padder.finalize()

    cipher = Cipher(algorithms.AES(FILE_KEY), modes.CBC(IV), backend=default_backend())
    encryptor = cipher.encryptor()

    encrypted = encryptor.update(padded) + encryptor.finalize()

    with open(output_path, "wb") as f:
        f.write(encrypted)


# ================== FILE DECRYPT ==================
def decrypt_file(file_path, ekey):

    FILE_KEY = hashlib.sha256(ekey.encode()).digest()

    with open(file_path, "rb") as f:
        encrypted = f.read()

    cipher = Cipher(algorithms.AES(FILE_KEY), modes.CBC(IV), backend=default_backend())
    decryptor = cipher.decryptor()

    decrypted_padded = decryptor.update(encrypted) + decryptor.finalize()

    unpadder = PKCS7(128).unpadder()
    return unpadder.update(decrypted_padded) + unpadder.finalize()


# ================== DOWNLOAD VIEW ==================
def download_file(request, filename):

    uid = request.session['uid']

    qry1 = "select * from user_data where em='" + uid + "'"
    data1 = dbconnection.selectdata(qry1)

    qry2 = "select * from dis_data where em='" + data1[7] + "'"
    data2 = dbconnection.selectdata(qry2)

    ekey = data2[5]

    file_path = os.path.join("p_app/static/d_file/", filename)
    decrypted_data = decrypt_file(file_path, ekey)

    mime_type, _ = mimetypes.guess_type(filename)
    mime_type = mime_type or "application/octet-stream"

    response = HttpResponse(decrypted_data, content_type=mime_type)
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


def download_file1(request, filename):

    uid = request.session['uid']

    

    qry2 = "select * from dis_data where em='" + uid + "'"
    data2 = dbconnection.selectdata(qry2)

    ekey = data2[5]

    file_path = os.path.join("p_app/static/d_file/", filename)
    decrypted_data = decrypt_file(file_path, ekey)

    mime_type, _ = mimetypes.guess_type(filename)
    mime_type = mime_type or "application/octet-stream"

    response = HttpResponse(decrypted_data, content_type=mime_type)
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


# ================== USER ADD DATA ==================
def user_add_data(request):

    uid = request.session['uid']
    qry2 = "select * from user_data where em='" + uid + "'"
    data2 = dbconnection.selectdata(qry2)

    if request.POST.get("b1"):
        t1 = request.POST.get("t1")
        t2 = request.POST.get("t2")
        today = str(date.today())

        up = request.FILES['up']
        rand_num = str(random.randint(100000, 999999))
        _, file_ext = os.path.splitext(up.name)
        new_filename = rand_num + file_ext

        file_path = os.path.join("p_app/static/d_file/", new_filename)

        # ✅ FIXED CALL (THIS WAS YOUR ERROR)
        encrypt_file(request, up, file_path)

        ins1 = (
            "INSERT INTO file_data(tit, `desc`, ph, dt, uid, did, st) "
            "VALUES ('" + t1 + "','" + t2 + "','" + new_filename + "','" +
            today + "','" + uid + "','" + data2[7] + "','0')"
        )
        dbconnection.insertdata(ins1)

        return HttpResponseRedirect("http://127.0.0.1:8000/user_add_data?x=1")

    qry1 = "select * from file_data order by id desc"
    data1 = dbconnection.selectalldata(qry1)

    return render(request, 'user/add_data.html', {'data1': data1})




def xor_encrypt_decrypt(data: bytes, key: str) -> bytes:
    key_bytes = key.encode()
    result = bytearray()

    for i in range(len(data)):
        result.append(data[i] ^ key_bytes[i % len(key_bytes)])

    return bytes(result)

def reencrypt_file(file_path, old_key, new_key):
    with open(file_path, "rb") as f:
        encrypted_data = f.read()

    # decrypt with OLD key
    decrypted_data = xor_encrypt_decrypt(encrypted_data, old_key)

    # encrypt with NEW key
    new_encrypted_data = xor_encrypt_decrypt(decrypted_data, new_key)

    with open(file_path, "wb") as f:
        f.write(new_encrypted_data)


#-----------------------------------------------INDEX-----------------------------------------------------


def index(request):
    
    return render(request,'index.html',{})





def register(request):
    if request.POST.get("b1"):

        t1=request.POST.get("t1")
        t2=request.POST.get("t2")
        t3=request.POST.get("t3")
        t4=request.POST.get("t4")
        t5=request.POST.get("t5")
        ta=request.POST.get("ta")
        ran11 = str(random.randint(100000, 999999))

        qry2="select * from dis_data where em='"+ta+"'"
        data2=dbconnection.selectdata(qry2)
        
        up=request.FILES['up']
        
        qry3="select * from user_log where uid='"+t4+"'"
        data1=dbconnection.selectdata(qry3)
        if data1:

            return HttpResponseRedirect("http://127.0.0.1:8000/register?y=1")
                       
            
            
        else:
            up = request.FILES['up']
            rand_num = str(random.randint(100000, 999999))

                    
            _, file_ext = os.path.splitext(up.name)

                    
            new_filename = rand_num + file_ext

                    
            fs = FileSystemStorage()
            filename = fs.save("b_app/static/img2/" + new_filename, up)

            ins1="INSERT INTO `user_data`(`nme`, `addr`, `cont`, `em`, `pas`, `ph`, `did`, `d_nme`, `sig`, `st`) VALUES ('"+t1+"','"+t2+"','"+t3+"','"+t4+"','"+t5+"','"+new_filename+"','"+ta+"','"+data2[1]+"','"+ran11+"','0')"
            dbconnection.insertdata(ins1)
            ins2="INSERT INTO `user_log`( `uid`, `pas`, `typ`, `st`) VALUES ('"+t4+"','"+t5+"','user','0')"
            dbconnection.insertdata(ins2)

            send_mail(
            subject="OTP",
            message="OTP is "+ran11,
            from_email=None,
            recipient_list=[t4],
            fail_silently=False,
    ) 
            return HttpResponseRedirect("http://127.0.0.1:8000/register?x=1")

      

    if request.GET.get("y"):
        y=1
        return render(request,'register1.html',{'y':y})

    if request.GET.get("x"):
        x=1
    else:
        x=0

    qry1="select * from dis_data"
    data1=dbconnection.selectalldata(qry1)
        
    return render(request,'register.html',{'data1':data1})







def login(request):
    if request.POST.get("b1"):
        t1=request.POST.get("t1")
        t2=request.POST.get("t2")

        qry1="select * from user_log where uid='"+t1+"' and pas='"+t2+"'"
        log=dbconnection.logindata(qry1)
        if log:
            if log[3]=="admin":
                request.session['uid']=t1
                return HttpResponseRedirect("http://127.0.0.1:8000/admin_home")


          
            if log[3]=="dis":
                request.session['uid']=t1
                return HttpResponseRedirect("http://127.0.0.1:8000/g_admin_home")

            
            if log[3]=="user":
                request.session['uid']=t1
                return HttpResponseRedirect("http://127.0.0.1:8000/login1")
            
            

            


        else:

            easygui.msgbox("Incorrect Username/Password", title="Success")

    if request.GET.get("y"):
        y=1
        return render(request,'login.html',{'y':y})



    
    
    return render(request,'login.html',{})




def login1(request):
    if request.POST.get("b1"):
        t1=request.POST.get("t1")
        uid=request.session['uid']

        qry1="select * from user_data where em='"+uid+"' and sig='"+t1+"'"
        log=dbconnection.logindata(qry1)
        
        if log:
            return HttpResponseRedirect("http://127.0.0.1:8000/user_home")
        else:
            easygui.msgbox("Admin has not accepted your requestzzzz", title="Pending")
    
    return render(request,'login1.html',{})


#-----------------------------------------------ADMIN-----------------------------------------------------



def admin_home(request):
    
    return render(request,'admin_page/home.html',{})


# def admin_add_dis(request):

    
#     if request.POST.get("b1"):

#         t1=request.POST.get("t1")
#         t2=request.POST.get("t2")
#         t3=request.POST.get("t3")
#         t4=request.POST.get("t4")
#         t5=request.POST.get("t5")
#         ran = str(random.randint(100000, 999999))
#         ran1 = encrypt(ran)

        
#         ins1="INSERT INTO `dis_data`(`dis`, `nme`, `cont`, `em`, `enc`, `st`) VALUES ('"+t1+"','"+t2+"','"+t3+"','"+t4+"','"+ran1+"','0')"
#         dbconnection.insertdata(ins1)
#         ins2="INSERT INTO `user_log`(`uid`, `pas`, `typ`, `st`) VALUES ('"+t4+"','"+t5+"','dis','0')"
#         dbconnection.insertdata(ins2) 
#         return HttpResponseRedirect("http://127.0.0.1:8000/admin_add_dis?x=1")

    

#     if request.GET.get("x"):
#         x=1
#     else:
#         x=0
   
#     qry1="select * from dis_data"
#     data1=dbconnection.selectalldata(qry1)
#     return render(request,'admin_page/add_dis.html',{'data1':data1})



def admin_add_dis(request):

    if request.POST.get("b1"):

        t1=request.POST.get("t1")
        t2=request.POST.get("t2")
        t3=request.POST.get("t3")
        t4=request.POST.get("t4")   # email
        t5=request.POST.get("t5")
        ran = str(random.randint(100000, 999999))
        ran1 = encrypt(ran)

        # ✅ Check if email already exists
        check_qry = "SELECT * FROM dis_data WHERE em='"+t4+"'"
        existing = dbconnection.selectalldata(check_qry)
        if existing:   # if any record found
            return render(request,'admin_page/add_dis.html', {
                'data1': dbconnection.selectalldata("select * from dis_data"),
                'error': "Email already exists"
            })
        

        ins1="INSERT INTO `dis_data`(`dis`, `nme`, `cont`, `em`, `enc`, `st`) VALUES ('"+t1+"','"+t2+"','"+t3+"','"+t4+"','"+ran1+"','0')"
        dbconnection.insertdata(ins1)
        ins2="INSERT INTO `user_log`(`uid`, `pas`, `typ`, `st`) VALUES ('"+t4+"','"+t5+"','dis','0')"
        dbconnection.insertdata(ins2) 
        return HttpResponseRedirect("http://127.0.0.1:8000/admin_add_dis?x=1")

    if request.GET.get("x"):
        x=1
    else:
        x=0
   
    qry1="select * from dis_data"
    data1=dbconnection.selectalldata(qry1)
    return render(request,'admin_page/add_dis.html',{'data1':data1})





def admin_user(request):
    

    qry1="select * from user_data where st='1'"
    data1=dbconnection.selectalldata(qry1)
    

        
    return render(request,'admin_page',{'data1':data1})



def admin_data(request):

    uid = request.session['uid']
    

    qry1 = "select * from file_data order by id desc"
    data1 = dbconnection.selectalldata(qry1)

    return render(request, 'admin_page/data.html', {'data1': data1})


    



#---------------------------------------------------G_ADMIN-----------------------------------------------------




def g_admin_home(request):
    
    return render(request,'g_admin/home.html',{})


def g_admin_req(request):
    
    uid=request.session['uid']
    qry1="select * from user_data where  did='"+uid+"' and st='0'"
    data1=dbconnection.selectalldata(qry1)
    

        
    return render(request,'g_admin/req.html',{'data1':data1})

def reencrypt_file_aes(file_path, old_key, new_key):
    import hashlib
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives.padding import PKCS7
    from cryptography.hazmat.backends import default_backend

    IV = b'\x00' * 16

    KEY_OLD = hashlib.sha256(old_key.encode()).digest()
    KEY_NEW = hashlib.sha256(new_key.encode()).digest()

    with open(file_path, "rb") as f:
        encrypted_data = f.read()

    # decrypt with OLD key
    cipher_old = Cipher(algorithms.AES(KEY_OLD), modes.CBC(IV), backend=default_backend())
    decryptor = cipher_old.decryptor()
    decrypted_padded = decryptor.update(encrypted_data) + decryptor.finalize()

    unpadder = PKCS7(128).unpadder()
    decrypted_data = unpadder.update(decrypted_padded) + unpadder.finalize()

    # encrypt with NEW key
    padder = PKCS7(128).padder()
    padded = padder.update(decrypted_data) + padder.finalize()

    cipher_new = Cipher(algorithms.AES(KEY_NEW), modes.CBC(IV), backend=default_backend())
    encryptor = cipher_new.encryptor()
    encrypted_new = encryptor.update(padded) + encryptor.finalize()

    with open(file_path, "wb") as f:
        f.write(encrypted_new)


def g_admin_upd1(request):

    if request.GET.get("upd"):
        de = request.GET.get("upd")
        did = request.GET.get("did")

        # 1️⃣ GET OLD KEY (before update)
        old_data = dbconnection.selectdata(
            "select enc from dis_data where em='" + did + "'"
        )
        old_key = old_data[0]   # ✅ FIXED

        # 2️⃣ GENERATE NEW KEY
        ran = str(random.randint(100000, 999999))
        new_key = encrypt(ran)

        # 3️⃣ RE-ENCRYPT ALL FILES USING OLD → NEW KEY
        files = dbconnection.selectalldata(
            "select ph from file_data where did='" + did + "'"
        )

        for f in files:
            file_path = os.path.join("p_app/static/d_file/", f[0])
            if os.path.exists(file_path):
                reencrypt_file_aes(file_path, old_key, new_key)

        # 4️⃣ NOW UPDATE DATABASE (AFTER FILES ARE SAFE)
        dbconnection.updatedata("update user_data set st='1' where em='" + de + "'")
        dbconnection.updatedata("update user_log set st='1' where uid='" + de + "'")
        dbconnection.updatedata(
            "update dis_data set enc='" + new_key + "' where em='" + did + "'"
        )

        return HttpResponseRedirect("http://127.0.0.1:8000/g_admin_req")

    if request.GET.get("del"):
        de = request.GET.get("del")
        dbconnection.updatedata("update user_data set st='2' where em='" + de + "'")
        dbconnection.updatedata("update user_log set st='2' where uid='" + de + "'")
        return HttpResponseRedirect("http://127.0.0.1:8000/g_admin_req")



def g_admin_user(request):
    
    uid=request.session['uid']

    qry1="select * from user_data where  did='"+uid+"' and st='1'"
    data1=dbconnection.selectalldata(qry1)
    

        
    return render(request,'g_admin/user.html',{'data1':data1})




def g_admin_data(request):

    uid = request.session['uid']
    

    qry1 = "select * from file_data where  did='"+uid+"' order by id desc"
    data1 = dbconnection.selectalldata(qry1)

    return render(request, 'g_admin/data.html', {'data1': data1})




#---------------------------------------------------USER-----------------------------------------------------

def user_home(request):
    
    return render(request,'user/home.html',{})



def user_user1(request):
    
    uid=request.session['uid']
    mid=request.GET.get("mid")
    qry2="select * from user_data where  em='"+uid+"'"
    data2=dbconnection.selectdata(qry2)    


    qry1="select * from user_data where  did !='"+data2[7]+"' and st='1' and em !='"+uid+"' "
    data1=dbconnection.selectalldata(qry1)
    

        
    return render(request,'user/user1.html',{'data1':data1,'mid':mid})



def user_upd1(request):

    if request.GET.get("upd"):
        upd=request.GET.get("upd")
        mid=request.GET.get("mid")
        uid=request.session['uid']

        ins1="INSERT INTO `msg_data`(`fid`, `uid`, `sid`, `st`) VALUES ('"+mid+"','"+upd+"','"+uid+"','0')"
        dbconnection.insertdata(ins1)


        return HttpResponseRedirect("http://127.0.0.1:8000/user_add_data")




def user_msg(request):
    
    uid=request.session['uid']
    


    qry1="select * from msg_data,file_data where file_data.id=msg_data.fid and msg_data.uid='"+uid+"' order by msg_data.id desc"
    data1=dbconnection.selectalldata(qry1)

        
    return render(request,'user/msg.html',{'data1':data1})




  







    
    








