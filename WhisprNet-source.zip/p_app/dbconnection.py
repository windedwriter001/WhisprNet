import os
import pymysql

# Database connection setup
conn = pymysql.connect(
    host=os.environ.get('DB_HOST', 'localhost'),
    port=int(os.environ.get('DB_PORT', '3306')),
    user=os.environ.get('DB_USER', 'root'),
    password=os.environ.get('DB_PASSWORD', ''),
    database=os.environ.get('DB_NAME', 'py_data'),
)

# Function to execute login queries
def logindata(query, params=None):
    cursor = conn.cursor()
    cursor.execute(query, params if params else ())  # Use params if provided
    data = cursor.fetchone()
    return data

# Function to select a single row (supports parameters)
def selectdata(query, params=None):
    cursor = conn.cursor()
    cursor.execute(query, params if params else ())  # Safe execution
    data = cursor.fetchone()
    return data

# Function to insert data with parameterized queries
def insertdata(query, params=None):
    cursor = conn.cursor()
    cursor.execute(query, params if params else ())  # Safe parameter execution
    conn.commit()

# Function to select all data (supports parameters)
def selectalldata(query, params=None):
    cursor = conn.cursor()
    cursor.execute(query, params if params else ())  # Safe execution
    data = cursor.fetchall()
    return data

# Function to update data (supports parameters)
def updatedata(query, params=None):
    cursor = conn.cursor()
    cursor.execute(query, params if params else ())  # Safe parameter execution
    conn.commit()



