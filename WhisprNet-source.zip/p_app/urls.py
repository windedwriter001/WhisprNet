from django.urls import path
from . import views

urlpatterns=[
#-----------------------------------------------INDEX-----------------------------------------------------
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('login1', views.login1),


#-----------------------------------------------ADMIN-----------------------------------------------------

    path('admin_home', views.admin_home),
    path('admin_add_dis', views.admin_add_dis),
   
    path('admin_user', views.admin_user),
    path('admin_data', views.admin_data),
    
#-----------------------------------------------G_ADMIN-----------------------------------------------------
    
    path('g_admin_home', views.g_admin_home),
    path('g_admin_req', views.g_admin_req),
    path('g_admin_upd1', views.g_admin_upd1),
    path('g_admin_user', views.g_admin_user),
    path('g_admin_data', views.g_admin_data),

#---------------------------------------------USER-----------------------------------------------------
    path('user_home', views.user_home),
    path('user_add_data', views.user_add_data),
    path('user_user1', views.user_user1),
    path('user_upd1', views.user_upd1),
    path('user_msg', views.user_msg),
    path("download/<str:filename>/", views.download_file, name="download_file"),
    path("download1/<str:filename>/", views.download_file1, name="download_file1"),

]